import { Component } from '@angular/core';
import { NavController, NavParams, ViewController } from 'ionic-angular';
import { Data } from '../../providers/data';
import { Parse } from 'parse';


@Component({
  selector: 'page-edit-item',
  templateUrl: 'edit-item.html'
})
export class EditItemPage {

  itemName;
  price;
  description;
  category;
  url;
  quantity;
  myDate;
  menuid;
  item;
  Menu;

  constructor(public navCtrl: NavController, public navParams: NavParams, public view: ViewController, public dataService: Data ) {

  }

  ionViewDidLoad() {
    this.itemName = this.navParams.get('item').itemName;
    this.price = this.navParams.get('item').price;
    this.category = this.navParams.get('item').category;
    this.url = this.navParams.get('item').url;
    this.description = this.navParams.get('item').description;
    this.quantity = this.navParams.get('item').quantity;
    this.menuid = this.navParams.get('item').id;
    this.item = this.navParams.get('item');
    this.Menu = Parse.Object.extend("Menu");
  }

  saveItem() {
    //console.log(this.menuid);
    var Menu = Parse.Object.extend("Menu");
    var query = new Parse.Query(Menu);
    //query.include("objectId");
    query.get(this.menuid);
    console.log(query);
    query.first({
        success: function (menu) {
            if (menu) {

                // Update part

                console.log("sucessfully called");
                console.log(menu.set("name", this.itemName));
                menu.set("name", this.itemName);
                menu.set("price", this.price);
                menu.set("category", this.category);
                menu.set("photoUrl", this.url);
                menu.set("description", this.description)

                menu.save(null, {
                    success: function (menu) {
                        console.log('Menu updated! Name: ' + menu.get("name") + ' and new price: ' + menu.get("price"));
                    },
                    error: function (response, error) {
                        console.log('Error: ' + error.message);
                    }
                });


                console.log('Menu found with name: ' + menu.get("name") + ' and price: ' + menu.get("price"));
            } else {
                console.log("Nothing found, please try again");
            }
        },
        error: function (error) {
            console.log("Error: " + error.code + " " + error.message);
        }
    });
    this.view.dismiss();
  }

  close() {
    this.view.dismiss();
  }

}
